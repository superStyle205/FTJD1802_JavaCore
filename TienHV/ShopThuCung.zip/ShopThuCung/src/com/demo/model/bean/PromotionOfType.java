package com.demo.model.bean;

public class PromotionOfType {
	private int promotionOfTypeId;
	private int percent;
	private int promotionProductId;
	private int isDelete;
	
	public PromotionOfType() {

	}
	
	public PromotionOfType(int promotionOfTypeId, int percent, int promotionProductId, int isDelete) {
		this.promotionOfTypeId = promotionOfTypeId;
		this.percent = percent;
		this.promotionProductId = promotionProductId;
		this.isDelete = isDelete;
	}
	
	public int getPromotionOfTypeId() {
		return promotionOfTypeId;
	}
	
	public void setPromotionOfTypeId(int promotionOfTypeId) {
		this.promotionOfTypeId = promotionOfTypeId;
	}
	
	public int getPercent() {
		return percent;
	}
	
	public void setPercent(int percent) {
		this.percent = percent;
	}
	
	public int getPromotionProductId() {
		return promotionProductId;
	}
	
	public void setPromotionProductId(int promotionProductId) {
		this.promotionProductId = promotionProductId;
	}
	
	public int getIsDelete() {
		return isDelete;
	}
	
	public void setIsDelete(int isDelete) {
		this.isDelete = isDelete;
	}
}
