package com.demo.model.bean;

public class Oder {
	private int oderId;
	private int userId;
	private String fullName;
	private String email;
	private String phoneNumber;
	private String tradingAddress;
	private String status;
	private double totalMoney;
	private String createDay;
		
	public Oder() {

	}
	
	public Oder(int oderId, int userId, String fullName, String email, String phoneNumber, String tradingAddress,
			String status, double totalMoney, String createDay) {
		super();
		this.oderId = oderId;
		this.userId = userId;
		this.fullName = fullName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.tradingAddress = tradingAddress;
		this.status = status;
		this.totalMoney = totalMoney;
		this.createDay = createDay;
	}

	public int getOderId() {
		return oderId;
	}
	
	public void setOderId(int oderId) {
		this.oderId = oderId;
	}
	
	public int getUserId() {
		return userId;
	}
	
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public String getFullName() {
		return fullName;
	}
	
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	public String getTradingAddress() {
		return tradingAddress;
	}
	
	public void setTradingAddress(String tradingAddress) {
		this.tradingAddress = tradingAddress;
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	public double getTotalMoney() {
		return totalMoney;
	}
	
	public void setTotalMoney(double totalMoney) {
		this.totalMoney = totalMoney;
	}
	
	public String getCreateDay() {
		return createDay;
	}
	
	public void setCreateDay(String createDay) {
		this.createDay = createDay;
	}
}
