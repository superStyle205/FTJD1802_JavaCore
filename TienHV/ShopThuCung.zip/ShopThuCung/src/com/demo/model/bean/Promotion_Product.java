package com.demo.model.bean;

public class Promotion_Product {
	private int promotion_ProductId;
	private int productId;
	private int promotionId;
	private int isDelete;
	
	public Promotion_Product() {
		
	}
	
	public Promotion_Product(int promotion_ProductId, int productId, int promotionId, int isDelete) {
		super();
		this.promotion_ProductId = promotion_ProductId;
		this.productId = productId;
		this.promotionId = promotionId;
		this.isDelete = isDelete;
	}
	
	public int getPromotion_ProductId() {
		return promotion_ProductId;
	}
	
	public void setPromotion_ProductId(int promotion_ProductId) {
		this.promotion_ProductId = promotion_ProductId;
	}
	
	public int getProductId() {
		return productId;
	}
	
	public void setProductId(int productId) {
		this.productId = productId;
	}
	
	public int getPromotionId() {
		return promotionId;
	}
	
	public void setPromotionId(int promontionId) {
		this.promotionId = promontionId;
	}

	public int getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(int isDelete) {
		this.isDelete = isDelete;
	}
}
