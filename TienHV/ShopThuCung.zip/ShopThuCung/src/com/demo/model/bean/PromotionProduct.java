package com.demo.model.bean;

public class PromotionProduct {
	private int promotionProductId;
	private String promotionProductName;
	private int count;
	private int categoryId;
	private int imageId;
	private String createDay;
	private int isDelete;
	
	public PromotionProduct() {
	
	}
	
	public PromotionProduct(int promotionProductId, String promotionProductName, int count, int categoryId, int imageId,
			String createDay, int isDelete) {
		this.promotionProductId = promotionProductId;
		this.promotionProductName = promotionProductName;
		this.count = count;
		this.categoryId = categoryId;
		this.imageId = imageId;
		this.createDay = createDay;
		this.isDelete = isDelete;
	}

	public int getPromotionProductId() {
		return promotionProductId;
	}

	public void setPromotionProductId(int promotionProductId) {
		this.promotionProductId = promotionProductId;
	}

	public String getPromotionProductName() {
		return promotionProductName;
	}

	public void setPromotionProductName(String promotionProductName) {
		this.promotionProductName = promotionProductName;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public int getImageId() {
		return imageId;
	}

	public void setImageId(int imageId) {
		this.imageId = imageId;
	}

	public String getCreateDay() {
		return createDay;
	}

	public void setCreateDay(String createDay) {
		this.createDay = createDay;
	}

	public int getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(int isDelete) {
		this.isDelete = isDelete;
	}
}
