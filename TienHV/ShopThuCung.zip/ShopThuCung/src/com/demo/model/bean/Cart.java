package com.demo.model.bean;

import java.util.List;
import java.util.Map;

public class Cart {
	private String fullName;
	private String email;
	private String phoneNumber;
	private String tradingAddress;
	private double totalMoney;
	private String username;
	private List<Map<String, String>> product;

	public Cart() {

	}

	public Cart(String fullName, String email, String phoneNumber, String tradingAddress, double totalMoney,
			String username) {
		this.fullName = fullName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.tradingAddress = tradingAddress;
		this.totalMoney = totalMoney;
		this.username = username;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getTradingAddress() {
		return tradingAddress;
	}

	public void setTradingAddress(String tradingAddress) {
		this.tradingAddress = tradingAddress;
	}

	public double getTotalMoney() {
		return totalMoney;
	}

	public void setTotalMoney(double totalMoney) {
		this.totalMoney = totalMoney;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public List<Map<String, String>> getProduct() {
		return product;
	}

	public void setProduct(List<Map<String, String>> product) {
		this.product = product;
	}
}
