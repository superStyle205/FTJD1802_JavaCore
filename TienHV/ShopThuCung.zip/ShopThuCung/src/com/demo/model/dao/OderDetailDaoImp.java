package com.demo.model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.demo.model.bean.OderDetail;

public class OderDetailDaoImp implements OderDetailDao {
	JdbcTemplate template;
	long millis=System.currentTimeMillis();  
	java.sql.Date date = new java.sql.Date(millis); 
    final SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd"); 
    final java.util.Calendar cal = GregorianCalendar.getInstance();  

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public int add(OderDetail oderDetail) {
		String sql = "insert into oderdetail value(" + 0 + ", " + oderDetail.getProductId() + ", "
				+ oderDetail.getOderId() + ", " + oderDetail.getCount() + ", " + oderDetail.getPrice() + ", '" + date + "')";
		return template.update(sql);
		
	}
	
	@Override
	public List<OderDetail> getOdersCurrentDay() {
		return template.query("SELECT users.username, oder.fullName, product.productName, oderdetail.count, price, oder.status, oder.totalMoney, oder.createDay FROM users JOIN oder ON users.userId = oder.userId JOIN oderdetail ON oderdetail.oderId = oder.oderId JOIN product ON product.productId = oderdetail.productId WHERE oder.createDay ='"+date +"'", new RowMapper<OderDetail>() {
			public OderDetail mapRow(ResultSet rs, int row) throws SQLException
			{
				OderDetail oderDetail = new OderDetail();

				oderDetail.setUserName(rs.getString(1));
				oderDetail.setFullName(rs.getString(2));
				oderDetail.setProductName(rs.getString(3));
				oderDetail.setCount(rs.getInt(4));
				oderDetail.setPrice(rs.getDouble(5));
				oderDetail.setStatus(rs.getString(6));
				oderDetail.setTotalMoney(rs.getDouble(7));
				oderDetail.setCreateDay(rs.getString(8));
				
				
				return oderDetail;
			}
		});
	}

	@Override
	public List<OderDetail> getOdersWeek() {
		 cal.setTime(date); 
		 cal.add(GregorianCalendar.DATE, -7); //thống kê 1 tuần 
		return template.query("SELECT users.username, oder.fullName, product.productName, oderdetail.count,"
				+ " price, oder.status, oder.totalMoney, oder.createDay "
				+ "FROM users JOIN oder ON users.userId = oder.userId JOIN oderdetail ON oderdetail.oderId = oder.oderId JOIN product ON"
				+ " product.productId = oderdetail.productId WHERE oder.createDay <='"+date +"'AND oder.createDay >='"+ df.format(cal.getTime()) +"'", new RowMapper<OderDetail>() {
			public OderDetail mapRow(ResultSet rs, int row) throws SQLException
			{
				OderDetail oderDetail = new OderDetail();

				oderDetail.setUserName(rs.getString(1));
				oderDetail.setFullName(rs.getString(2));
				oderDetail.setProductName(rs.getString(3));
				oderDetail.setCount(rs.getInt(4));
				oderDetail.setPrice(rs.getDouble(5));
				oderDetail.setStatus(rs.getString(6));
				oderDetail.setTotalMoney(rs.getDouble(7));
				oderDetail.setCreateDay(rs.getString(8));
				
				
				return oderDetail;
			}
		});
	}

	@Override
	public List<OderDetail> getOdersMonth() {
		cal.setTime(date); 
		 cal.add(GregorianCalendar.MONTH, -1); //thống kê 1 tháng
		return template.query("SELECT users.username, oder.fullName, product.productName, oderdetail.count,"
				+ " price, oder.status, oder.totalMoney, oder.createDay "
				+ "FROM users JOIN oder ON users.userId = oder.userId JOIN oderdetail ON oderdetail.oderId = oder.oderId JOIN product ON"
				+ " product.productId = oderdetail.productId WHERE oder.createDay <='"+date +"'AND oder.createDay >='"+ df.format(cal.getTime()) +"'", new RowMapper<OderDetail>() {
			public OderDetail mapRow(ResultSet rs, int row) throws SQLException
			{
				OderDetail oderDetail = new OderDetail();

				oderDetail.setUserName(rs.getString(1));
				oderDetail.setFullName(rs.getString(2));
				oderDetail.setProductName(rs.getString(3));
				oderDetail.setCount(rs.getInt(4));
				oderDetail.setPrice(rs.getDouble(5));
				oderDetail.setStatus(rs.getString(6));
				oderDetail.setTotalMoney(rs.getDouble(7));
				oderDetail.setCreateDay(rs.getString(8));
				
				
				return oderDetail;
			}
		});
	}

	@Override
	public List<OderDetail> getOdersYear() {
		cal.setTime(date); 
		 cal.add(GregorianCalendar.YEAR, -1); //thống kê 1 năm
		return template.query("SELECT users.username, oder.fullName, product.productName, oderdetail.count,"
				+ " price, oder.status, oder.totalMoney, oder.createDay "
				+ "FROM users JOIN oder ON users.userId = oder.userId JOIN oderdetail ON oderdetail.oderId = oder.oderId JOIN product ON"
				+ " product.productId = oderdetail.productId WHERE oder.createDay <='"+date +"'AND oder.createDay >='"+ df.format(cal.getTime()) +"'", new RowMapper<OderDetail>() {
			public OderDetail mapRow(ResultSet rs, int row) throws SQLException
			{
				OderDetail oderDetail = new OderDetail();

				oderDetail.setUserName(rs.getString(1));
				oderDetail.setFullName(rs.getString(2));
				oderDetail.setProductName(rs.getString(3));
				oderDetail.setCount(rs.getInt(4));
				oderDetail.setPrice(rs.getDouble(5));
				oderDetail.setStatus(rs.getString(6));
				oderDetail.setTotalMoney(rs.getDouble(7));
				oderDetail.setCreateDay(rs.getString(8));
				
				return oderDetail;
			}
		});
	}
}
