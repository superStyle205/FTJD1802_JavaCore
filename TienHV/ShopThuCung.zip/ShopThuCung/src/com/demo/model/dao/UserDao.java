package com.demo.model.dao;

import java.util.List;

import com.demo.model.bean.User;

public interface UserDao {
	
	public int add(User user);
	
	public int update(User user);
	
	public int delete(int userId);
	
	public User getUserByUserId(int userId);
	
	List<User> getUser();
	
	public User getUserByUsername(String username);
	
	List<String> getRolesByUsername(String username);
}
