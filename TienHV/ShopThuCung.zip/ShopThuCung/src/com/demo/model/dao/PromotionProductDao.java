package com.demo.model.dao;

import java.util.List;

import com.demo.model.bean.PromotionProduct;

public interface PromotionProductDao {
	public int add(PromotionProduct promotionProduct);
	
	public int update(PromotionProduct promotionProduct);
	
	public int delete(int promotionProductId);
	
	public PromotionProduct getPromotionProductById(int promotionProductId);
	
	List<PromotionProduct> getPromotionProduct();
}
