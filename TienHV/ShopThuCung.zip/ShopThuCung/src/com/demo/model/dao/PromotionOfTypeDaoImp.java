package com.demo.model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.demo.model.bean.PromotionOfType;

public class PromotionOfTypeDaoImp implements PromotionOfTypeDao {
	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
		
	@Override
	public int add(PromotionOfType promotionOfType) {
		String sql = "insert into promotionoftype value("+0+" ,"+promotionOfType.getPercent()+" ,"+promotionOfType.getPromotionProductId()+" ,"+promotionOfType.getIsDelete()+")";
		return template.update(sql);
	}

	@Override
	public int update(PromotionOfType promotionOfType) {
		String sql = "update promotionoftype set percent = " + promotionOfType.getPercent() + ", promotionProductId = " + promotionOfType.getPromotionProductId() 
		+", isDelete = 0 where promotionOfTypeId = " + promotionOfType.getPromotionOfTypeId();
		return template.update(sql);
	}

	@Override
	public int delete(int promotionOfTypeId) {
		String sql = "update  promotionoftype set isDelete = 1 where promotionOfTypeId = "+ promotionOfTypeId +"";
		return template.update(sql);
	}

	@Override
	public PromotionOfType getPromotionOfTypeById(int promotionOfTypeId) {
		String sql = "select * from promotionoftype where promotionOfTypeId = ?";
		return template.queryForObject(sql, new Object[] {promotionOfTypeId}, new BeanPropertyRowMapper<PromotionOfType>(PromotionOfType.class));
	}

	@Override
	public List<PromotionOfType> getPromotionOfType() {
		return template.query("select * from promotionoftype", new RowMapper<PromotionOfType>() {
			public PromotionOfType mapRow(ResultSet rs, int row) throws SQLException
			{
				PromotionOfType promotionOfType = new PromotionOfType();
				
				promotionOfType.setPromotionOfTypeId(rs.getInt(1));
				promotionOfType.setPercent(rs.getInt(2));
				promotionOfType.setPromotionProductId(rs.getInt(3));
				promotionOfType.setIsDelete(rs.getInt(4));
				
				return promotionOfType;
			}
		});
	}
}
