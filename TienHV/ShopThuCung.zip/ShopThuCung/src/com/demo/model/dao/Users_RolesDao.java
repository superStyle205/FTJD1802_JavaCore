package com.demo.model.dao;

import java.util.List;

import com.demo.model.bean.Users_Roles;

public interface Users_RolesDao {
	
	public int add(Users_Roles users_Roles);
	
	public int update(Users_Roles users_Roles);
	
	public int delete(int Id);
	
	public Users_Roles getUsers_RolesById(int id);
	
	List<Users_Roles> getUsers_Roles();
}
