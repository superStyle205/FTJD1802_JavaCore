package com.demo.model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.demo.model.bean.Promotion_Product;

public class Promotion_ProductDaoImp implements Promotion_ProductDao {
	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
		
	@Override
	public int add(Promotion_Product promotion_Product) {
		String sql = "insert into promotion_product value("+0+","+promotion_Product.getProductId()+","+promotion_Product.getPromotionId()+","+promotion_Product.getIsDelete()+")";
		return template.update(sql);
	}

	@Override
	public int update(Promotion_Product promotion_Product) {
		String sql = "update promotion_product set productId = " +promotion_Product.getProductId()+", promontId = "+ promotion_Product.getPromotionId()
			+ ", isDelete = 0 where promotion_ProductId = " + promotion_Product.getPromotion_ProductId();
		return template.update(sql);
	}

	@Override
	public int delete(int promontion_ProductId) {
		String sql = "update  promontion_product set isDelete = 1 where promontion_ProductId = "+ promontion_ProductId +"";
		return template.update(sql);
	}

	@Override
	public Promotion_Product getPromotion_ProductById(int promotion_ProductId) {
		String sql = "select * from promontion_product where promontion_ProductId = ?";
		return template.queryForObject(sql, new Object[] {promotion_ProductId}, new BeanPropertyRowMapper<Promotion_Product>(Promotion_Product.class));
	}

	@Override
	public List<Promotion_Product> getPromotion_Product() {
		return template.query("select * from promontion_product", new RowMapper<Promotion_Product>() {
			public Promotion_Product mapRow(ResultSet rs, int row) throws SQLException
			{
				Promotion_Product promotion_Product = new Promotion_Product();
				
				promotion_Product.setPromotion_ProductId(rs.getInt(1));
				promotion_Product.setProductId(rs.getInt(2));
				promotion_Product.setPromotionId(rs.getInt(3));
				promotion_Product.setIsDelete(rs.getInt(4));
				
				return promotion_Product;
			}
		});
	}
}
