package com.demo.model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.demo.model.bean.Product;

public class ProductDaoImp implements ProductDao {
	JdbcTemplate template;
	long millis = System.currentTimeMillis();
	java.sql.Date date = new java.sql.Date(millis);

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public List<Product> getProductByCategoryId(int categoryId) {
		String sql = "SELECT images.imageName, imageLink, product.productId, product.productName, product.oldPrice, product.currentPrice, product.productDescription, product.count FROM images JOIN product ON images.imageId = product.imageId JOIN category ON category.categoryId = product.categoryId WHERE category.categoryId = '"
				+ categoryId + "'";
		return template.query(sql, new RowMapper<Product>() {
			@Override
			public Product mapRow(ResultSet rs, int row) throws SQLException {
				Product product = new Product();

				product.setImageName(rs.getString(1));
				product.setImageLink(rs.getString(2));
				product.setProductId(rs.getInt(3));
				product.setProductName(rs.getString(4));
				product.setOldPrice(rs.getDouble(5));
				product.setCurrentPrice(rs.getDouble(6));
				product.setProductDescription(rs.getString(7));
				product.setCount(rs.getInt(8));

				return product;
			}
		});
	}

	@Override
	public Product getProductByProductId(int productId) {
		String sql = "SELECT images.imageName, imageLink, product.productId, product.productName, product.currentPrice, product.productDescription, product.count FROM images JOIN product ON images.imageId = product.imageId WHERE productId = ?";
		return template.queryForObject(sql, new Object[] { productId },
				new BeanPropertyRowMapper<Product>(Product.class));
	}

	@Override
	public List<Product> getProduct() {
		String sql = "SELECT images.imageName, imageLink, product.productId, product.productName, product.oldPrice, product.currentPrice, product.productDescription, product.count FROM images JOIN product ON images.imageId = product.imageId JOIN category ON category.categoryId = product.categoryId ORDER BY RAND() LIMIT 12";
		return template.query(sql, new RowMapper<Product>() {
			@Override
			public Product mapRow(ResultSet rs, int row) throws SQLException {
				Product product = new Product();

				product.setImageName(rs.getString(1));
				product.setImageLink(rs.getString(2));
				product.setProductId(rs.getInt(3));
				product.setProductName(rs.getString(4));
				product.setOldPrice(rs.getDouble(5));
				product.setCurrentPrice(rs.getDouble(6));
				product.setProductDescription(rs.getString(7));
				product.setCount(rs.getInt(8));

				return product;
			}
		});
	}

	@Override
	public int add(Product product) {
		String sql = "insert into product value(" + 0 + ", '" + product.getProductName() + "', " + product.getOldPrice()
				+ ", " + product.getCurrentPrice() + ", '" + product.getProductDescription() + "', "
				+ product.getCount() + ", " + product.getImageId() + ", " + product.getCategoryId() + ", '" + date
				+ "', " + product.getIsDelete() + ")";
		return template.update(sql);
	}

	@Override
	public int update(Product product) {
		String sql = "update product set productName = '" + product.getProductName() + "', OldPrice = "
				+ product.getOldPrice() + ", currentPrice = " + product.getCurrentPrice() + ", productDescription = '"
				+ product.getProductDescription() + "', count = " + product.getCount() + ", imageId = "
				+ product.getImageId() + ", categoryId = " + product.getCategoryId() + ", createDay = '" + date
				+ "', isDelete = 0 where productId = " + product.getProductId();
		return template.update(sql);
	}

	@Override
	public int delete(int productId) {
		String sql = "update  product set isDelete = 1 where productId= " + productId + "";
		return template.update(sql);
	}

	@Override
	public Product getProductById(int productId) {
		String sql = "select * from product where productId = ?";
		return template.queryForObject(sql, new Object[] { productId },
				new BeanPropertyRowMapper<Product>(Product.class));
	}

	@Override
	public List<Product> get_Product() {
		String sql = "SELECT * FROM product";
		return template.query(sql, new RowMapper<Product>() {
			@Override
			public Product mapRow(ResultSet rs, int row) throws SQLException {
				Product product = new Product();

				product.setProductId(rs.getInt(1));
				product.setProductName(rs.getString(2));
				product.setOldPrice(rs.getDouble(3));
				product.setCurrentPrice(rs.getDouble(4));
				product.setProductDescription(rs.getString(5));
				product.setCount(rs.getInt(6));
				product.setImageId(rs.getInt(7));
				product.setCategoryId(rs.getInt(8));
				product.setCreateDay(rs.getString(9));
				product.setIsDelete(rs.getInt(10));

				return product;
			}
		});
	}
	
}
