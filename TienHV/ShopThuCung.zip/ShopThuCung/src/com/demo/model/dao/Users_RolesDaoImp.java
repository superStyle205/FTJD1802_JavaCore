package com.demo.model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.demo.model.bean.Users_Roles;

public class Users_RolesDaoImp implements Users_RolesDao {
	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public int add(Users_Roles users_Roles) {
		String sql = "insert into users_roles value("+ 0 +","+ users_Roles.getUserId() +","+ users_Roles.getRoleId() +","+ users_Roles.getIsDelete() +")";
		return template.update(sql);

	}

	@Override
	public int update(Users_Roles users_Roles) {
		String sql = "update users_roles set userId = "+ users_Roles.getUserId() +", roleId = "+ users_Roles.getRoleId()  +", isDelete = 0 where id = "+ users_Roles.getId();
		return template.update(sql);
	}

	@Override
	public int delete(int id) {
		String sql = "update  users_roles set isDelete = 1 where id = "+ id;
		return template.update(sql);
	}

	@Override
	public Users_Roles getUsers_RolesById(int id) {
		String sql = "select * from users_roles where id = ?";
		return template.queryForObject(sql, new Object[] {id}, new BeanPropertyRowMapper<Users_Roles>(Users_Roles.class));
	}

	@Override
	public List<Users_Roles> getUsers_Roles() {
		return template.query("SELECT * FROM users_roles ", new RowMapper<Users_Roles>() {
			public Users_Roles mapRow(ResultSet rs, int row) throws SQLException
			{
				Users_Roles users_Roles = new Users_Roles();
				users_Roles.setId(rs.getInt(1));
				users_Roles.setUserId(rs.getInt(2));
				users_Roles.setRoleId(rs.getInt(3));
				users_Roles.setIsDelete(rs.getInt(4));
				
				return users_Roles;
			}
	});
	}
}
