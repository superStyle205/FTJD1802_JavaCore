package com.demo.model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.demo.model.bean.PetDetail;

public class DetailDaoImp implements DetailDao {
	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public List<PetDetail> getPetDetailByProductId(int productId) {
		String sql = "SELECT images.imageName, images.imageLink, product.productName, product.oldPrice, product.currentPrice, product.count, "
				+ "petdetail.height, petdetail.weight, petdetail.lifeExpectancy, petdetail.furColor, petdetail.petPersonality, petdetail.takeCareOf, "
				+ "petdetail.origin FROM images JOIN product ON images.imageId = product.imageId JOIN petdetail ON product.productId = petdetail.productId "
				+ "WHERE product.productId = " + productId;
		return template.query(sql, new RowMapper<PetDetail>() {
			@Override
			public PetDetail mapRow(ResultSet rs, int row) throws SQLException
			{
				PetDetail petDetail = new PetDetail();
				
				petDetail.setImageName(rs.getString(1));
				petDetail.setImageLink(rs.getString(2));
				petDetail.setProductName(rs.getString(3));
				petDetail.setOldPrice(rs.getDouble(4));
				petDetail.setCurrentPrice(rs.getDouble(5));
				petDetail.setCount(rs.getInt(6));
				petDetail.setHeight(rs.getString(7));
				petDetail.setWeight(rs.getString(8));
				petDetail.setLifeExpectancy(rs.getString(9));
				petDetail.setFurColor(rs.getString(10));
				petDetail.setPetPersonality(rs.getString(11));
				petDetail.setTakeCareOf(rs.getString(12));
				petDetail.setOrigin(rs.getString(13));

				return petDetail;
			}
		});
	}
}
