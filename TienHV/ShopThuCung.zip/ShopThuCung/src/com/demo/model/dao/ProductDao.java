package com.demo.model.dao;

import java.util.List;

import com.demo.model.bean.Product;

public interface ProductDao {
	List<Product> getProductByCategoryId(int categoryId);
	
	List<Product> getProduct();
	
	public Product getProductByProductId(int productId);
	
	public int add(Product product);
	
	public int update(Product product);
	
	public int delete(int productId);
	
	public Product getProductById(int productId);
	
	List<Product> get_Product();
	
	default  void test() {};

}
