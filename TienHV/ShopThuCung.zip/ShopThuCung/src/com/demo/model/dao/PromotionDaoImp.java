package com.demo.model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.demo.model.bean.Promotion;

public class PromotionDaoImp implements PromotionDao {
	JdbcTemplate template;
	long millis=System.currentTimeMillis();  
	java.sql.Date date = new java.sql.Date(millis);  

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
		
	@Override
	public int add(Promotion promotion) {
		String sql = "insert into promotion value("+ 0 +","+promotion.getPromotionOfTypeId()+",'"+promotion.getPromotionDate()+"','"
				+promotion.getPromotionEndDate()+"','"+promotion.getPromotionOfDescription()+"','"+date+"',"+promotion.getIsDelete()+")";
		return template.update(sql);
	}

	@Override
	public int update(Promotion promotion) {
		String sql = "update promotion set promotionOfTypeId = " + promotion.getPromotionOfTypeId() + ",promotionDate = '" + promotion.getPromotionDate() 
		+"', promotionEndDate = '"+ promotion.getPromotionEndDate() + "', promotionOfDescription = '" + promotion.getPromotionOfDescription()
		+ "', createDay = '" + date + "', isDelete = 0 where promotionId = " + promotion.getPromotionId();
		return template.update(sql);
	}

	@Override
	public int delete(int promotionId) {
		String sql = "update  promotion set isDelete = 1 where promotionId = "+ promotionId +"";
		return template.update(sql);
	}

	@Override
	public Promotion getPromotionByPromotionId(int promotionId) {
		String sql = "select * from promotion where promotionId = ?";
		return template.queryForObject(sql, new Object[] {promotionId}, new BeanPropertyRowMapper<Promotion>(Promotion.class));
	}

	@Override
	public List<Promotion> getPromotion() {
		return template.query("select * from promotion", new RowMapper<Promotion>() {
			public Promotion mapRow(ResultSet rs, int row) throws SQLException
			{
				Promotion promotion = new Promotion();
				
				promotion.setPromotionId(rs.getInt(1));
				promotion.setPromotionOfTypeId(rs.getInt(2));
				promotion.setPromotionDate(rs.getString(3));
				promotion.setPromotionEndDate(rs.getString(4));
				promotion.setPromotionOfDescription(rs.getString(5));
				promotion.setCreateDay(rs.getString(6));
				promotion.setIsDelete(rs.getInt(7));
				
				return promotion;
			}
		});
	}
}
