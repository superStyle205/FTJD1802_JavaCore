package com.demo.model.dao;

import java.util.List;

import com.demo.model.bean.Service;

public interface ServiceDao {
	List<Service> getService();
}
