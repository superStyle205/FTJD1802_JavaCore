package com.demo.model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.demo.model.bean.PromotionProduct;

public class PromotionProductDaoImp implements PromotionProductDao {
	JdbcTemplate template;
	long millis=System.currentTimeMillis();  
	java.sql.Date date = new java.sql.Date(millis);  

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
		
	@Override
	public int add(PromotionProduct promotionProduct) {
		String sql = "insert into promotionproduct value("+0+",'"+promotionProduct.getPromotionProductName()+"', "+promotionProduct.getCount() +","
		+promotionProduct.getCategoryId() +", "+promotionProduct.getImageId()+",'"+date+"', "+promotionProduct.getIsDelete()+")";
		return template.update(sql);
	}

	@Override
	public int update(PromotionProduct promotionProduct) {
		String sql = "update promotionproduct set promotionProductName = '" +promotionProduct.getPromotionProductName()+"', count =  " 
				+promotionProduct.getCount()+", categoryId = "+ promotionProduct.getCategoryId() + ", imageId = " + promotionProduct.getImageId() +", createDay = '" + date + "', isDelete = 0 "
						+ "where promotionProductId = " + promotionProduct.getPromotionProductId() ;
		return template.update(sql);
	}

	@Override
	public int delete(int promotionProductId) {
		String sql = "update  promotionproduct set isDelete = 1 where promotionProductId = "+ promotionProductId +"";
		return template.update(sql);
	}

	@Override
	public PromotionProduct getPromotionProductById(int promotionProductId) {
		String sql = "select * from promotionproduct where promotionProductId = ?";
		return template.queryForObject(sql, new Object[] {promotionProductId}, new BeanPropertyRowMapper<PromotionProduct>(PromotionProduct.class));
	}

	@Override
	public List<PromotionProduct> getPromotionProduct() {
		return template.query("select * from promotionproduct", new RowMapper<PromotionProduct>() {
			public PromotionProduct mapRow(ResultSet rs, int row) throws SQLException
			{
				PromotionProduct promotionProduct = new PromotionProduct();
				
				promotionProduct.setPromotionProductId(rs.getInt(1));
				promotionProduct.setPromotionProductName(rs.getString(2));
				promotionProduct.setCount(rs.getInt(3));
				promotionProduct.setCategoryId(rs.getInt(4));
				promotionProduct.setImageId(rs.getInt(5));
				promotionProduct.setCreateDay(rs.getString(6));
				promotionProduct.setIsDelete(rs.getInt(7));
				
				return promotionProduct;
			}
		});
	}
}
