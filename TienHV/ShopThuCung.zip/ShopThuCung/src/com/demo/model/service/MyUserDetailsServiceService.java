package com.demo.model.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.demo.model.bean.User;
import com.demo.model.dao.UserDao;

@Service
public class MyUserDetailsServiceService implements UserDetailsService {

	@Autowired
	private UserDao userDao;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userDao.getUserByUsername(username);
		List<String> roles = userDao.getRolesByUsername(username);
		List<GrantedAuthority> authority = new ArrayList<GrantedAuthority>();
		for (String roleName : roles) {
			authority.add(new SimpleGrantedAuthority(roleName));
		}

		return new org.springframework.security.core.userdetails.User(username, user.getPassword(), true, true, true,
				true, authority);
	}

}
