package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.demo.model.bean.Category;
import com.demo.model.bean.Service;
import com.demo.model.dao.CategoryDao;
import com.demo.model.dao.ServiceDao;

@Controller
public class ServiceController {
	@Autowired
	private CategoryDao categoryDao;
	@Autowired
	private ServiceDao serviceDao;
	
	@RequestMapping(path = "/service")
	public String getCategory(ModelMap model) {
		List<Category> category = categoryDao.getCategory();
		model.addAttribute("category", category);
		List<Service> service = serviceDao.getService();
		model.addAttribute("service", service);
		return "service";
	}
}
