package com.demo.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.demo.model.bean.Category;
import com.demo.model.bean.Product;
import com.demo.model.dao.CategoryDao;
import com.demo.model.dao.ProductDao;


@Controller
public class ShopController {
	@Autowired
	private ProductDao productDao;
	@Autowired
	private CategoryDao categoryDao;
	
	@RequestMapping(path = "/shop", method = { RequestMethod.GET })
	public String shopView(ModelMap model) {
		List<Category> category = categoryDao.getCategory();
		model.addAttribute("category", category);
		List<Product> product = productDao.getProduct();
		model.addAttribute("product", product);
		
	     return "shop";
	} 
	
	@RequestMapping(path = "/shop/{categoryId}", method = { RequestMethod.GET })
	public String shop(ModelMap model, @PathVariable int categoryId) {
		List<Category> category = categoryDao.getCategory();
		model.addAttribute("category", category);
		List<Product> product = productDao.getProductByCategoryId(categoryId);
		model.addAttribute("product", product);
	     return "shop";
	} 
	
	@RequestMapping(path="/shop/cart", method= {RequestMethod.GET})
	public String viewCart(ModelMap model) {
		List<Category> category = categoryDao.getCategory();
		model.addAttribute("category", category);
		return "cart";
	}

	
	//Quản lí sản phẩm
	 @RequestMapping("/viewproduct/addproduct")
		public String addRole(Model model) {
		 model.addAttribute("command", new Product());
			return "addproduct";
		}
		
		@RequestMapping(value = "/viewproduct/saveproduct", method = {RequestMethod.POST})
		public String saveRole( @ModelAttribute("command") Product product) {
			productDao.add(product);
			return "redirect:/viewproduct";
		}
		
		 @RequestMapping("/viewproduct")
		 public String viewemp(Model model){    
			 model.addAttribute("command", new Product());
		     List<Product> list = productDao.get_Product();
		     model.addAttribute("list",list);  
		     return "productmanager";    
		 } 
		
		 @RequestMapping(value="/viewproduct/editproduct/{productId}", method = {RequestMethod.GET})
		 public String editRole(@PathVariable int productId, Model model) {
			 Product product = productDao.getProductById(productId);
			 model.addAttribute("command", product);
			 return "editproduct";
		 }
		 
		 @RequestMapping(value = "/viewproduct/editsaveproduct", method = {RequestMethod.POST})
		 public String editsaveRole(@ModelAttribute("command") Product product ) {
			productDao.update(product);
			return "redirect:/viewproduct";
		}
		 
		 @RequestMapping(value = "/viewproduct/deleteproduct/{productId}", method = {RequestMethod.GET})
		 public String deleteRole(@PathVariable int productId) {
			 productDao.delete(productId);
			 return"redirect:/viewproduct";
		 }
}
