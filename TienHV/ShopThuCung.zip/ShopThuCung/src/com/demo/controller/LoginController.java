package com.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.demo.model.bean.Category;
import com.demo.model.dao.CategoryDao;

@Controller
public class LoginController {
	@Autowired
	private CategoryDao categoryDao;
	
	@RequestMapping(path="/login", method= {RequestMethod.GET})
	public String loginRequest(ModelMap model) {
		List<Category> category = categoryDao.getCategory();
		model.addAttribute("category", category);
		return "login";
	}
	
	@RequestMapping(path="/login?error", method= {RequestMethod.GET})
	public String Error404(ModelMap model) {
		List<Category> category = categoryDao.getCategory();
		model.addAttribute("category", category);
		return "404";
	}
	
	@RequestMapping("/logout")
	public String logout(HttpServletRequest request, HttpServletResponse response) {
		org.springframework.security.core.Authentication auth = SecurityContextHolder.getContext().getAuthentication();  
        if (auth != null){      
           new SecurityContextLogoutHandler().logout(request, response, auth);  
        }  
         return "redirect:/login";  
	}
}