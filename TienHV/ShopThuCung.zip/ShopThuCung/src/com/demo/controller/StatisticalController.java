package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.demo.model.bean.OderDetail;
import com.demo.model.dao.OderDetailDao;

@Controller
public class StatisticalController {
	@Autowired
	private OderDetailDao oderdetailDao ;
	
	@RequestMapping(path = "/order", method = {RequestMethod.GET})
	public String getStatistical(ModelMap model) {
		return "ordermanager";
	}
	@RequestMapping(path = "/order/currentorder", method = {RequestMethod.GET})
	public String getStatisticalcurrentday(ModelMap model) {
		List<OderDetail> oderDetail = oderdetailDao.getOdersCurrentDay();
		model.addAttribute("oderDetail", oderDetail);
		return "statisticalcurrentday";
	}
	@RequestMapping(path = "/order/orderbyweek", method = {RequestMethod.GET})
	public String getStatisticalcurrentweek(ModelMap model) {
		List<OderDetail> oderDetail = oderdetailDao.getOdersWeek();
		model.addAttribute("oderDetail", oderDetail);
		return "statisticalcurrentweek";
	}
	
	@RequestMapping(path = "/order/orderbymonth", method = {RequestMethod.GET})
	public String getStatisticalcurrentmonth(ModelMap model) {
		List<OderDetail> oderDetail = oderdetailDao.getOdersMonth();
		model.addAttribute("oderDetail", oderDetail);
		return "statisticalcurrentmonth";
	}
	
	@RequestMapping(path = "/order/orderbyyear", method = {RequestMethod.GET})
	public String getStatisticalcurrentyear(ModelMap model) {
		List<OderDetail> oderDetail = oderdetailDao.getOdersYear();
		model.addAttribute("oderDetail", oderDetail);
		return "statisticalcurrentyear";
	}
	

}
