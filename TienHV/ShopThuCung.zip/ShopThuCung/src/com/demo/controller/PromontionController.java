package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.demo.model.bean.Promotion;
import com.demo.model.bean.PromotionOfType;
import com.demo.model.bean.PromotionProduct;
import com.demo.model.dao.PromotionDao;
import com.demo.model.dao.PromotionOfTypeDao;
import com.demo.model.dao.PromotionProductDao;

@Controller
public class PromontionController {
	@Autowired
	private PromotionOfTypeDao promotionOfTypeDao;
	@Autowired
	private PromotionProductDao promotionProductDao;
	@Autowired 
	private PromotionDao promotionDao;
	
	@RequestMapping("/viewpromotion/addpromotion")
	public String add(Model model) {
		model.addAttribute("command", new Promotion());
		return "addpromotion";
	}
	
	@RequestMapping(value = "/viewpromotion/savepromotion", method = {RequestMethod.POST})
	public String save(@ModelAttribute("command") Promotion promotion) {
		promotionDao.add(promotion);
		return "redirect:/viewpromotion";
	}
	
	 @RequestMapping("/viewpromotion")
	 public String viewemp(Model model){    
		 
	     List<Promotion> promotion = promotionDao.getPromotion();
	     model.addAttribute("promotion", promotion); 
	     
	     List<PromotionOfType> promotionOfType = promotionOfTypeDao.getPromotionOfType();
	     model.addAttribute("promotionOfType", promotionOfType); 
	     
	     List<PromotionProduct> promotionProduct = promotionProductDao.getPromotionProduct();
	     model.addAttribute("promotionProduct", promotionProduct); 
	     
	     return "promotionmanager";    
	 } 
	 
	 @RequestMapping(value="/viewpromotion/editpromotion/{promotionId}", method = {RequestMethod.GET})
	 public String edit(@PathVariable int promotionId, Model model) {
		 Promotion promotion = promotionDao.getPromotionByPromotionId(promotionId);
		 model.addAttribute("command", promotion);
		 return "editpromotion";
	 }
	 
	 @RequestMapping(value = "/viewpromotion/editsavepromotion", method = {RequestMethod.POST})
	 public String editsave(@ModelAttribute("command") Promotion promotion) {
		promotionDao.update(promotion);
		return "redirect:/viewpromotion";
	}
	 
	 @RequestMapping(value = "/viewpromotion/deletepromotion/{promotionId}", method = {RequestMethod.GET})
	 public String delete(@PathVariable int promotionId) {
		 promotionDao.delete(promotionId);
		 return"redirect:/viewpromotion";
	 }
	 
	 //Loại khuyến mãi
		@RequestMapping("/viewpromotion/addpromotionoftype")
		public String addpromotionoftype(Model model) {
			model.addAttribute("command", new PromotionOfType());
			return "addpromotionoftype";
		}
		
		@RequestMapping(value = "/viewpromotion/savepromotionoftype", method = {RequestMethod.POST})
		public String savepromotionoftype(@ModelAttribute("command") PromotionOfType promotionOfType) {
			promotionOfTypeDao.add(promotionOfType);
			return "redirect:/viewpromotion";
		}
		 
		 @RequestMapping(value="/viewpromotion/editpromotionoftype/{promotionOfTypeId}", method = {RequestMethod.GET})
		 public String editpromotionoftype(@PathVariable int promotionOfTypeId, Model model) {
			 PromotionOfType promotionOfType = promotionOfTypeDao.getPromotionOfTypeById(promotionOfTypeId);
			 model.addAttribute("command", promotionOfType);
			 return "editpromotionoftype";
		 }
		 
		 @RequestMapping(value = "/viewpromotion/editsavepromotionoftype", method = {RequestMethod.POST})
		 public String editsavepromotionoftype(@ModelAttribute("command") PromotionOfType promotionOfType) {
			 promotionOfTypeDao.update(promotionOfType);
			return "redirect:/viewpromotion";
		}
		 
		 @RequestMapping(value = "/viewpromotion/deletepromotionoftype/{promotionOfTypeId}", method = {RequestMethod.GET})
		 public String deletepromotionoftype(@PathVariable int promotionOfTypeId) {
			 promotionOfTypeDao.delete(promotionOfTypeId);
			 return"redirect:/viewpromotion";
		 }
		 
		 //Sản phẩm khuyến mãi
			@RequestMapping("/viewpromotion/addpromotionproduct")
			public String addPromotionProduct(Model model) {
				model.addAttribute("command", new PromotionProduct());
				return "addpromotionproduct";
			}
			
			@RequestMapping(value = "/viewpromotion/savepromotionproduct", method = {RequestMethod.POST})
			public String savePromotionProduct(@ModelAttribute("command") PromotionProduct promotionProduct) {
				promotionProductDao.add(promotionProduct);
				return "redirect:/viewpromotion";
			}
			 
			 @RequestMapping(value="/viewpromotion/editpromotionproduct/{promotionProductId}", method = {RequestMethod.GET})
			 public String editPromotionProduct(@PathVariable int promotionProductId, Model model) {
				 PromotionProduct promotionProduct = promotionProductDao.getPromotionProductById(promotionProductId);
				 model.addAttribute("command", promotionProduct);
				 return "editpromotionproduct";
			 }
			 
			 @RequestMapping(value = "/viewpromotion/editsavepromotionproduct", method = {RequestMethod.POST})
			 public String editsavePromotionProduct(@ModelAttribute("command") PromotionProduct promotionProduct) {
				 promotionProductDao.update(promotionProduct);
				return "redirect:/viewpromotion";
			}
			 
			 @RequestMapping(value = "/viewpromotion/deletepromotionproduct/{promotionProductId}", method = {RequestMethod.GET})
			 public String deletePromotionProduct(@PathVariable int promotionProductId) {
				 promotionProductDao.delete(promotionProductId);
				 return"redirect:/viewpromotion";
			 }
}
