package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.demo.model.bean.Category;
import com.demo.model.dao.CategoryDao;

@Controller
public class ContactController {
	@Autowired
	private CategoryDao categoryDao;
	
	@RequestMapping(path= "/contact")
	public String getCategory(ModelMap model) {
		List<Category> category = categoryDao.getCategory();
		model.addAttribute("category", category);
		return "contact";
	}
}
