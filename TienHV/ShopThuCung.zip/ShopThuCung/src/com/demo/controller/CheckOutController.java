package com.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.demo.model.bean.Cart;
import com.demo.model.bean.Category;
import com.demo.model.bean.CheckOut;
import com.demo.model.bean.Oder;
import com.demo.model.bean.OderDetail;
import com.demo.model.bean.User;
import com.demo.model.dao.CategoryDao;
import com.demo.model.dao.OderDao;
import com.demo.model.dao.OderDetailDao;
import com.demo.model.dao.UserDao;

@Controller
public class CheckOutController {
	@Autowired
	private OderDao oderDao;
	@Autowired
	private CategoryDao categoryDao;;
	@Autowired
	private UserDao userDao;
	@Autowired
	private OderDetailDao oderDetailDao;
	private CheckOut checkOut;
	private Oder oder;
	private User user;
	private List<Map<String, String>> list;
	private List<CheckOut> listCheckOut;
	
	
	
	@RequestMapping(value = "/shop/cart/payment", method = RequestMethod.POST)
	public @ResponseBody String oder(@ModelAttribute Cart cart) {
		String status = "Chưa thanh toán";
		
		user = userDao.getUserByUsername(cart.getUsername());
		int userId = user.getUserId();
		
		oder = new Oder();
		
		oder.setUserId(userId);
		oder.setFullName(cart.getFullName());
		oder.setEmail(cart.getEmail());
		oder.setPhoneNumber(cart.getPhoneNumber());
		oder.setTradingAddress(cart.getTradingAddress());
		oder.setStatus(status);
		oder.setTotalMoney(cart.getTotalMoney());
		oderDao.add(oder);// Đây là khi bấm vào nút đặt hàng thì sẽ tạo mới oder
		
		list = cart.getProduct();
		
		for (int i = 0; i < list.size(); i++) {
			
			Map<String, String> myMap = list.get(i);
			listCheckOut = new ArrayList<CheckOut>();
			checkOut = new CheckOut();
			
			for(int i1 = 0; i1 < list.size() - (list.size() - 1) ; i1++) {
				
				
				checkOut.setCount(Integer.parseInt(myMap.get("count")));
				checkOut.setId(Integer.parseInt(myMap.get("id")));
				checkOut.setImage(myMap.get("image"));
				checkOut.setName(myMap.get("name"));
				checkOut.setPrice(Double.parseDouble(myMap.get("price")));
							
				listCheckOut.add(checkOut);			
			}
			
			oder = new Oder();
			oder = oderDao.getOderIdMax(user.getUserId());
			for (CheckOut check : listCheckOut) {
				OderDetail oderDetail = new OderDetail();
				oderDetail.setProductId(check.getId());
				oderDetail.setOderId(oder.getOderId());
				oderDetail.setCount(check.getCount());
				oderDetail.setPrice(check.getPrice());
				
				oderDetailDao.add(oderDetail);//Đây là sau khi oder đượct tạo mới ta tiếp tục tạo mới oderDetail dựa trên oderId mới được tạo ra
			}
		}

		return "payment";
	}

	@RequestMapping(value = "/shop/cart/payment", method = RequestMethod.GET)
	public String odersuccess() {

		return "payment";
	}

	@RequestMapping(path = "/shop/cart/checkout", method = { RequestMethod.GET })
	public String viewCheckOut(ModelMap model) {
		List<Category> category = categoryDao.getCategory();
		model.addAttribute("category", category);
		return "checkout";
	}
}
